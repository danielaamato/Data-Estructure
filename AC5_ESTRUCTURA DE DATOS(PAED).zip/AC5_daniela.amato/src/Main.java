import java.util.List;
import java.util.PriorityQueue;

public class Main {

    public static void main(String[] args)
    {
        Globals.init();
        int best = Integer.MAX_VALUE;
        int cutOff = 0, totalNodes = 0, solutionNodes = 0;

        PriorityQueue<BoxTreasureConfig> queue = new PriorityQueue<>();

        BoxTreasureConfig first = new BoxTreasureConfig();
        queue.add(first);
        totalNodes++;

        while (!queue.isEmpty())
        {
            BoxTreasureConfig config = queue.poll();

            List<BoxTreasureConfig> children = config.expand();
            totalNodes += children.size();

            for (BoxTreasureConfig child : children)
            {
                if (child.completedBoxes())
                {
                    if (child.getCost() == best)
                    {
                        solutionNodes++;
                    }

                    if (child.getCost() < best)
                    {
                        best = child.getCost();
                        System.out.println("Mejor solución (por ahora):");
                        System.out.println(child);
                    }
                }
                else
                {
                    if (child.getCost() < best)
                    {
                        queue.offer(child);
                    }
                    else
                    {
                        cutOff++;
                    }
                }
            }
        }

        System.out.println("Nodos totales: " + totalNodes);
        System.out.println("Nodos solución: " + solutionNodes);
        System.out.println("Nodos podados: " + cutOff);
    }
}
