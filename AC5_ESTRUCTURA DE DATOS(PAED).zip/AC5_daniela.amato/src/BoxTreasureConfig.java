import java.util.ArrayList;
import java.util.List;

public class BoxTreasureConfig
        implements Comparable<BoxTreasureConfig>
{
    private int level;
    private int volumenTreasuresLeft;
    private ArrayList<BoxTreasure> boxTreasures;
    private ArrayList<Integer> treasures;


    public BoxTreasureConfig()
    {
        treasures = new ArrayList<>();
        volumenTreasuresLeft = 0;

        for (int i = 0; i < Globals.treasures.length; i++)
        {
            treasures.add(Globals.treasures[i]);
            volumenTreasuresLeft += Globals.treasures[i];
        }

        BoxTreasure boxTreasure = new BoxTreasure(Globals.volumenBox);
        Integer treasure = treasures.get(0);
        boxTreasure.addTreasure(treasure);
        volumenTreasuresLeft -= treasure;
        treasures.remove(treasure);

        boxTreasures = new ArrayList<>();
        boxTreasures.add(boxTreasure);
    }

    public BoxTreasureConfig(BoxTreasureConfig that)
    {
        this.treasures = new ArrayList<>(that.treasures);
        this.boxTreasures = new ArrayList<>();
        this.volumenTreasuresLeft = that.volumenTreasuresLeft;

        for (BoxTreasure boxTreasure : that.boxTreasures)
        {
            this.boxTreasures.add(new BoxTreasure(boxTreasure));
        }
    }


    public boolean completedBoxes()
    {
        return this.treasures.size() == 0;
    }


    public List<BoxTreasureConfig> expand()
    {
        List<BoxTreasureConfig> children = new ArrayList<>();

        int lastBox = boxTreasures.size() - 1;
        int volumenFreeBox = boxTreasures.get(lastBox).getFreeVolumen();

        for (Integer treasure : treasures)
        {
            BoxTreasureConfig next = new BoxTreasureConfig(this);

            if (treasure <= volumenFreeBox)
            {
                next.boxTreasures.get(lastBox).addTreasure(treasure);
            }
            else
            {
                BoxTreasure newBoxTreasure = new BoxTreasure(Globals.volumenBox);
                newBoxTreasure.addTreasure(treasure);
                next.boxTreasures.add(newBoxTreasure);
            }

            next.volumenTreasuresLeft -= treasure;
            next.treasures.remove(treasure);
            children.add(next);
        }

        return children;
    }

    public int getCost()
    {
        return this.boxTreasures.size();
    }

    public int estimate()
    {
        return volumenTreasuresLeft;
    }

    @Override
    public int compareTo(BoxTreasureConfig that)
    {
        if (this.getCost() == that.getCost())
        {
            return this.estimate() - that.estimate();
        }

        return this.getCost() - that.getCost();
    }

    @Override
    public String toString()
    {
        String text = "";
        text += "Número de cajas: " + this.boxTreasures.size() + "\n";

        for (BoxTreasure caja : boxTreasures)
        {
            text += caja.toString() + "\n";
        }

        text += "\nMonedas de oro total: " + this.boxTreasures.size() * 500 + "\n";

        return text;
    }
}

