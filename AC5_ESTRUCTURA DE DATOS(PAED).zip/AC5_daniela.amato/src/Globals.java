public class Globals {
    public static final int N = 8;

    public static int[] treasures = {1,2,2,3,3,3,4,5};
    public static int volumenBox = 6;

    public static final int MIN_VOL_TESORO = 1;
    public static final int MAX_VOL_TESORO = 5;
    public static final int MAX_VOL_CAJA = 3;

    public static void init()
    {
        //Random r = new Random();
        //TESOROS = new int[N];
        //for (int i = 0; i < N; i++)
        //    TESOROS[i] = r.nextInt(MAX_VOL_TESORO) + MIN_VOL_TESORO;

        //VOL_CAJA = MAX_VOL_TESORO + r.nextInt(MAX_VOL_CAJA) + 1;
    }
}
