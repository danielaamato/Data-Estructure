public class BoxTreasure
{
    private final int volumen;
    private final int[] treasures;
    private int freeVolumen;
    private int numTreasures;

    public BoxTreasure(int volumen)
    {
        this.volumen = volumen;
        this.treasures = new int[Globals.N];
        this.freeVolumen = volumen;
        this.numTreasures = 0;
    }

    public BoxTreasure(BoxTreasure that)
    {
        this.volumen = that.volumen;
        this.treasures = that.treasures.clone();
        this.freeVolumen = that.freeVolumen;
        this.numTreasures = that.numTreasures;
    }

    public int getFreeVolumen()
    {
        return freeVolumen;
    }

    public void addTreasure(int volumenTreasure)
    {
        treasures[numTreasures] = volumenTreasure;
        numTreasures++;
        freeVolumen -= volumenTreasure;
    }

    @Override
    public String toString() {
        String text = "";

        for (int i = 0; i < numTreasures; i++)
        {
            text += treasures[i] + " ";
        }
        return text;
    }
}

