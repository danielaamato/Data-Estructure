Para implementar este algoritmo se ha utilizado como lenguaje de programación: Java.
Para implementar este algoritmo se ha utilizado como IDE: IntelliJ IDEA.

Para ejecutar el algoritmo y cambiar valores de entrada se ha facilitado una clase "Globals" la cual contiene las variables para definir 
el volumen maximo de la caja, los volumenes de cada tesoro, y la cantidad de tesoros. A su vez, se ha dejado comentada la posibilidad de 
definir estas mismas variables de manera aleatoria. 